﻿Plugin: NumberTextHighlightPlugin
Command: NUMRED
DLL: NumberTextHighlightPlugin-v0.1.0-autocad2021.dll

Steps:
1. Extract this ZIP.
2. Run unblock.ps1 in this folder:
   powershell -ExecutionPolicy Bypass -File .\unblock.ps1
3. Open AutoCAD and run NETLOAD.
4. Select NumberTextHighlightPlugin-v0.1.0-autocad2021.dll from this extracted folder.
5. Run command NUMRED.

If AutoCAD still cannot load the DLL:
- Restart AutoCAD and NETLOAD again.
- Make sure the DLL file properties no longer show an Unblock button.
- Do not load the DLL from inside the ZIP, browser cache, OneDrive temp folder, or another temporary location.
