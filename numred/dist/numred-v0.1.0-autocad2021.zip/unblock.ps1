﻿$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll = Join-Path $dir "numred-v0.1.0-autocad2021.dll"
if (-not (Test-Path -LiteralPath $dll)) {
  throw "DLL not found: $dll"
}
Unblock-File -LiteralPath $dll
Write-Host "Unblocked: $dll"
Write-Host "You can now load this DLL in AutoCAD with NETLOAD."
